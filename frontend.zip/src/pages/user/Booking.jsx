import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useLocation } from "react-router-dom";
import { QRCodeCanvas } from "qrcode.react";
import "./Booking.css";

const Booking = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const [cities, setCities] = useState([]);
  const [areas, setAreas] = useState([]);
  const [errors, setErrors] = useState({});
  const [selectedAreaDetails, setSelectedAreaDetails] = useState(null);

  const [showQR, setShowQR] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [showCustomEndTime, setShowCustomEndTime] = useState(false);

  // New states for Auto-Confirm Payment
  const [upiId, setUpiId] = useState("");
  const [upiError, setUpiError] = useState("");
  const [isUpiValidated, setIsUpiValidated] = useState(false);
  const [countdown, setCountdown] = useState(15);
  const [createdBookingId, setCreatedBookingId] = useState(null);
  const [paymentToken, setPaymentToken] = useState("");
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  const [formData, setFormData] = useState({
    city: "",
    area: "",
    price: "",
    paymentMethod: "",
    date: "",
    startTime: "",
    endTime: "",
    slotNumber: "",
    vehicleNumber: "",
    vehicleType: ""
  });

  const [availability, setAvailability] = useState({
    totalSlots: 0,
    bookedSlots: [],
    pendingSlots: [],
    loading: false
  });

  const fetchAvailability = async () => {
    if (!selectedAreaDetails?._id || !formData.date || !formData.startTime || !formData.endTime) return;
    try {
      setAvailability(prev => ({ ...prev, loading: true }));
      const res = await axios.post("http://localhost:5000/api/bookings/check-availability", {
        locationId: selectedAreaDetails._id,
        date: formData.date,
        startTime: formData.startTime,
        endTime: formData.endTime
      });
      setAvailability({
        totalSlots: res.data.totalSlots || selectedAreaDetails.totalSlots,
        bookedSlots: res.data.bookedSlots || [],
        pendingSlots: res.data.pendingSlots || [],
        loading: false
      });

      // If the currently selected slot is now booked, clear it
      if (formData.slotNumber && res.data.bookedSlots.includes(formData.slotNumber)) {
        setFormData(prev => ({ ...prev, slotNumber: "" }));
      }
    } catch (error) {
      console.log("AVAILABILITY ERROR:", error);
      setAvailability(prev => ({ ...prev, loading: false }));
    }
  };

  useEffect(() => {
    fetchAvailability();
    
    // Auto-refresh availability every 10 seconds to show locked slots in real-time
    const interval = setInterval(fetchAvailability, 10000);
    return () => clearInterval(interval);
  }, [selectedAreaDetails, formData.date, formData.startTime, formData.endTime]);

  // Centralized Price Calculation Effect
  useEffect(() => {
    if (formData.startTime && selectedAreaDetails) {
      const rate = Number(selectedAreaDetails.price);
      const dynamicPrice = calculateDynamicPrice(
        formData.startTime, 
        formData.endTime, 
        rate
      );
      
      // Update price only if it has changed to avoid infinite loops
      setFormData(prev => {
        if (prev.price === dynamicPrice) return prev;
        return { ...prev, price: dynamicPrice };
      });
    } else {
      setFormData(prev => {
        if (prev.price === "") return prev;
        return { ...prev, price: "" };
      });
    }
  }, [formData.startTime, formData.endTime, selectedAreaDetails]);

  useEffect(() => {
    if (location.state) {
      const { city, date, startTime, endTime, vehicleNumber, vehicleType, preSelectedArea } = location.state;
      if (city && date) {
        let updatedEndTime = endTime || "";

        // Auto-calculate End Time if Start Time is provided
        if (startTime && !endTime) {
          const [hours, minutes] = startTime.split(":").map(Number);
          const endHours = (hours + 1) % 24;
          const formattedEndHours = endHours.toString().padStart(2, "0");
          const formattedMinutes = minutes.toString().padStart(2, "0");
          updatedEndTime = `${formattedEndHours}:${formattedMinutes}`;
        }

        setFormData(prev => ({ 
          ...prev, 
          city, 
          date, 
          startTime: startTime || "", 
          endTime: updatedEndTime,
          vehicleNumber: vehicleNumber || "",
          vehicleType: vehicleType || ""
        }));
        fetchAreasAndSelect(city, preSelectedArea);
      }
    }
  }, [location.state]);

  const fetchAreasAndSelect = async (city, preSelectedArea) => {
    try {
      const res = await axios.get(`http://localhost:5000/api/location/areas/${city}`);
      setAreas(res.data);
      if (preSelectedArea) {
        const areaObj = res.data.find(a => a.area === preSelectedArea);
        if (areaObj) {
          setFormData(prev => ({ 
            ...prev, 
            area: areaObj.area,
            price: areaObj.price
          }));
          setSelectedAreaDetails(areaObj);
        }
      }
    } catch (error) {
      console.log("AREA ERROR:", error);
    }
  };

  useEffect(() => {
    const userStr = sessionStorage.getItem("user_user");
    if (!userStr) {
      alert("Please login first");
      navigate("/login");
    }
  }, [navigate]);

  useEffect(() => {
    const fetchCities = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/location/cities");
        setCities(res.data);
      } catch (error) {
        console.log("CITY ERROR:", error);
      }
    };
    fetchCities();
  }, []);

  const handleCityChange = async (e) => {
    const city = e.target.value;
    setFormData({ ...formData, city: city, area: "", price: "", slotNumber: "" });
    try {
      const res = await axios.get(`http://localhost:5000/api/location/areas/${city}`);
      setAreas(res.data);
    } catch (error) {
      console.log("AREA ERROR:", error);
    }
  };

  const handleAreaChange = (e) => {
    const area = e.target.value;
    const selectedArea = areas.find((a) => a.area === area);
    if (!selectedArea) {
      setSelectedAreaDetails(null);
      return;
    }
    setSelectedAreaDetails(selectedArea);
    setFormData({ ...formData, area: area, slotNumber: "" });
  };

  const calculateDynamicPrice = (startTime, endTime, hourlyRate) => {
    const rate = Number(hourlyRate);
    if (!startTime || isNaN(rate) || rate === 0) return 0;
    
    let endT = endTime;
    
    // Default to 1 hour if endTime is not provided
    if (!endT) {
      const [hours, minutes] = startTime.split(":").map(Number);
      const endHours = (hours + 1) % 24;
      const formattedEndHours = endHours.toString().padStart(2, "0");
      const formattedMinutes = minutes.toString().padStart(2, "0");
      endT = `${formattedEndHours}:${formattedMinutes}`;
    }
    
    const [startH, startM] = startTime.split(":").map(Number);
    const [endH, endM] = endT.split(":").map(Number);
    
    let startTotalMinutes = (startH * 60) + startM;
    let endTotalMinutes = (endH * 60) + endM;
    
    let diffInMinutes = endTotalMinutes - startTotalMinutes;
    
    // Handle cases where end time is on the next day (e.g., 11 PM to 1 AM)
    if (diffInMinutes <= 0) {
      diffInMinutes += 24 * 60;
    }
    
    const diffInHours = diffInMinutes / 60;
    
    // Exact proportional calculation (e.g., 1.5 hours * ₹20 = ₹30)
    // Using Math.ceil for final total to avoid decimal rupees
    return Math.ceil(diffInHours * rate);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
      slotNumber: (name === "date" || name === "startTime" || name === "endTime") ? "" : prev.slotNumber
    }));
  };

  const validate = () => {
    let newErrors = {};
    if (!formData.city) newErrors.city = "Select city";
    if (!formData.area) newErrors.area = "Select area";
    if (!formData.vehicleNumber) newErrors.vehicleNumber = "Vehicle number required";
    if (!formData.vehicleType) newErrors.vehicleType = "Vehicle type required";
    if (!formData.paymentMethod) newErrors.paymentMethod = "Select payment";
    if (!formData.date) newErrors.date = "Select date";
    if (!formData.startTime) newErrors.startTime = "Start time required";
    
    // Only validate End Time if the user has manually entered it
    if (showCustomEndTime && formData.endTime && formData.startTime && formData.startTime >= formData.endTime) {
      newErrors.endTime = "Invalid duration";
    }
    
    if (!formData.slotNumber) {
      newErrors.slotNumber = "Select a slot from grid";
    } else if (availability.bookedSlots.includes(formData.slotNumber)) {
      newErrors.slotNumber = "This slot is no longer available. Please select another.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) {
      alert("Please fill all required fields and select an available slot.");
      return;
    }
    
    try {
      setIsProcessing(true);

      const userStr = sessionStorage.getItem("user_user");
      const user = JSON.parse(userStr);

      // Release old lock if it exists (e.g. user clicked twice or changed mind)
      if (createdBookingId) {
        try {
          await axios.delete(`http://localhost:5000/api/bookings/delete/${createdBookingId}`);
        } catch (e) {
          console.log("Old lock already gone or failed to delete");
        }
      }
      
      const start = new Date(`${formData.date}T${formData.startTime}`);
      let finalEndTime = formData.endTime;
      if (!finalEndTime) {
        const [hours, minutes] = formData.startTime.split(":").map(Number);
        const endHours = (hours + 1) % 24;
        finalEndTime = `${endHours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
      }
      const end = new Date(`${formData.date}T${finalEndTime}`);

      const finalAmount = formData.price || calculateDynamicPrice(
        formData.startTime, 
        formData.endTime, 
        selectedAreaDetails.price
      );

      const lockData = {
        userId: user._id,
        vehicleNumber: formData.vehicleNumber || user.vehicleNumber,
        vehicleType: formData.vehicleType || user.vehicleType,
        city: formData.city,
        area: formData.area,
        parkingRate: selectedAreaDetails.price,
        paymentMethod: formData.paymentMethod || "Pending",
        date: formData.date,
        startTime: start,
        endTime: end,
        slotNumber: formData.slotNumber,
        locationId: selectedAreaDetails._id,
        amount: finalAmount,
        status: "Pending"
      };

      if (!finalAmount || finalAmount <= 0) {
        alert("Error calculating price. Please re-select your area or time.");
        setIsProcessing(false);
        return;
      }

      // Create a Pending booking to LOCK the slot
      const res = await axios.post("http://localhost:5000/api/bookings/add", lockData);
      setCreatedBookingId(res.data.bookingId);
      
      setIsProcessing(false);
      // Reset payment states before showing modal
      setUpiId("");
      setUpiError("");
      setIsUpiValidated(false);
      setPaymentSuccess(false);
      setCountdown(60);
      // For QR, we show the QR immediately in the modal
      if (formData.paymentMethod === "QR") {
        setShowQR(true);
        setIsUpiValidated(false);
      } else {
        setShowQR(false);
        setIsUpiValidated(false);
      }
      
      setShowModal(true);
    } catch (error) {
      console.error("LOCK ERROR:", error);
      alert(error.response?.data?.message || "Failed to lock slot. It might have been taken.");
      setIsProcessing(false);
      fetchAvailability(); // Refresh to show taken slots
    }
  };

  const handleUpiValidation = async () => {
    if (!upiId.includes("@")) {
      setUpiError("Invalid UPI ID. Must contain '@'.");
      return;
    }
    setUpiError("");
    
    try {
      setIsProcessing(true);
      // Simulate sending UPI request
      await new Promise(resolve => setTimeout(resolve, 1000));

      setIsProcessing(false);
      setIsUpiValidated(true);
      setShowQR(true); // This will start the 60s countdown
      setCountdown(60);
    } catch (error) {
      console.log("BOOKING ERROR:", error);
      alert(error.response?.data?.message || "Failed to initialize booking details.");
      setIsProcessing(false);
    }
  };

  const handleAutoConfirm = async () => {
    try {
      if (!createdBookingId) {
        alert("Booking ID is missing.");
        return;
      }
      
      // Auto-confirm payment status
      await axios.post("http://localhost:5000/api/bookings/auto-confirm-payment", {
        bookingId: createdBookingId
      });
      
      // Update local session storage with new vehicle details
      const userStr = sessionStorage.getItem("user_user");
      if (userStr) {
        const user = JSON.parse(userStr);
        user.vehicleNumber = formData.vehicleNumber;
        user.vehicleType = formData.vehicleType;
        sessionStorage.setItem("user_user", JSON.stringify(user));
      }

      setPaymentSuccess(true);
      setShowQR(false); 
      
      setTimeout(() => {
        setShowModal(false);
        navigate("/profile");
      }, 2000);
    } catch (error) {
      console.log("AUTO CONFIRM ERROR:", error);
      alert(`Payment confirmation failed: ${error.message}`);
    }
  };

  useEffect(() => {
    let timerId;
    if (showQR && countdown > 0 && !paymentSuccess) {
      timerId = setInterval(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
    } else if (countdown === 0 && showQR && !paymentSuccess) {
      handleAutoConfirm();
    }
    return () => clearInterval(timerId);
  }, [showQR, countdown, paymentSuccess, createdBookingId]);

  const confirmFinalBooking = async () => {
    try {
      const userStr = sessionStorage.getItem("user_user");
      if (!userStr) {
        alert("Login required");
        navigate("/login");
        return;
      }
      setIsProcessing(true);
      // Just update status to Allocated for Cash payment
      await axios.put(`http://localhost:5000/api/bookings/update-status/${createdBookingId}`, {
        status: "Allocated"
      });

      // Update local session storage with new vehicle details
      if (userStr) {
        const user = JSON.parse(userStr);
        user.vehicleNumber = formData.vehicleNumber;
        user.vehicleType = formData.vehicleType;
        sessionStorage.setItem("user_user", JSON.stringify(user));
      }

      alert(`Booking Successful! Slot Number: ${formData.slotNumber} confirmed.`);
      setShowModal(false);
      setIsProcessing(false);
      navigate("/profile");
    } catch (error) {
      console.log("BOOKING ERROR:", error);
      alert(error.response?.data?.message || "Booking failed");
      setIsProcessing(false);
    }
  };

  const upiLink = `upi://pay?pa=milanparmar568-1@oksbi&pn=ParkingSystem&am=${formData.price}&cu=INR&tn=ParkingBooking`;

  const handleCloseModal = async () => {
    if (createdBookingId && !paymentSuccess) {
      try {
        await axios.delete(`http://localhost:5000/api/bookings/delete/${createdBookingId}`);
        setCreatedBookingId(null);
        fetchAvailability();
      } catch (error) {
        console.error("Error releasing lock on modal close:", error);
      }
    }
    setShowModal(false);
  };

  return (
    <div className="booking-page">
      <div className="booking-container">
        <div className="booking-card">
          <h2>Parking Slot Booking</h2>
          {location.state?.preSelectedArea && (
            <div className="booking-pre-summary">
              <div className="summary-item">
                <span className="summary-label">City:</span>
                <span className="summary-value">{formData.city}</span>
              </div>
              <div className="summary-item">
                <span className="summary-label">Area:</span>
                <span className="summary-value">{formData.area}</span>
              </div>
              <div className="summary-item">
                <span className="summary-label">Date:</span>
                <span className="summary-value">{new Date(formData.date).toLocaleDateString()}</span>
              </div>
              <div className="summary-item">
                <span className="summary-label">Time:</span>
                <span className="summary-value">{formData.startTime} to {formData.endTime}</span>
              </div>
              <div className="summary-item">
                <span className="summary-label">Vehicle:</span>
                <span className="summary-value">{formData.vehicleNumber} ({formData.vehicleType})</span>
              </div>
              <button 
                className="change-selection-btn" 
                onClick={() => navigate("/", { 
                  state: { 
                    preSelectedCity: formData.city, 
                    preSelectedDate: formData.date, 
                    preSelectedStartTime: formData.startTime, 
                    preSelectedEndTime: formData.endTime,
                    preSelectedVehicleNumber: formData.vehicleNumber,
                    preSelectedVehicleType: formData.vehicleType
                  } 
                })}
                style={{marginTop: "10px", background: "none", border: "none", color: "#1e3c72", fontWeight: "bold", cursor: "pointer", textDecoration: "underline"}}
              >
                Change Selection
              </button>
            </div>
          )}

          <form onSubmit={handleSubmit}>
            {!location.state?.preSelectedArea && (
              <>
                <select name="city" value={formData.city} onChange={handleCityChange}>
                  <option value="">Select City</option>
                  {cities.map((c, index) => (
                    <option key={index} value={c}>{c}</option>
                  ))}
                </select>
                {errors.city && <span className="error">{errors.city}</span>}

                <select name="area" value={formData.area} onChange={handleAreaChange}>
                  <option value="">Select Area</option>
                  {areas.map((a) => (
                    <option key={a._id} value={a.area}>{a.area}</option>
                  ))}
                </select>
                {errors.area && <span className="error">{errors.area}</span>}

                <input
                  type="date"
                  name="date"
                  value={formData.date}
                  onChange={handleChange}
                  min={new Date().toISOString().split("T")[0]}
                />
                {errors.date && <span className="error">{errors.date}</span>}

                <div className="time-selection" style={{marginTop: "15px"}}>
                  <div style={{display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", marginBottom: "10px"}}>
                    <div>
                      <label style={{display: "block", marginBottom: "5px", fontSize: "14px", fontWeight: "600"}}>Vehicle Number</label>
                      <input
                        type="text"
                        name="vehicleNumber"
                        value={formData.vehicleNumber}
                        onChange={handleChange}
                        placeholder="GJ01AB1234"
                        style={{width: "100%", textTransform: "uppercase"}}
                      />
                      {errors.vehicleNumber && <span className="error">{errors.vehicleNumber}</span>}
                    </div>
                    <div>
                      <label style={{display: "block", marginBottom: "5px", fontSize: "14px", fontWeight: "600"}}>Vehicle Type</label>
                      <select
                        name="vehicleType"
                        value={formData.vehicleType}
                        onChange={handleChange}
                        style={{width: "100%"}}
                      >
                        <option value="">Select Type</option>
                        <option value="Two Wheeler">Two Wheeler</option>
                        <option value="Four Wheeler">Four Wheeler</option>
                      </select>
                      {errors.vehicleType && <span className="error">{errors.vehicleType}</span>}
                    </div>
                  </div>

                  <div style={{marginBottom: "10px"}}>
                    <label style={{display: "block", marginBottom: "5px", fontSize: "14px", fontWeight: "600"}}>Start Time</label>
                    <input
                      type="time"
                      name="startTime"
                      value={formData.startTime}
                      onChange={handleChange}
                      style={{width: "100%"}}
                    />
                    {errors.startTime && <span className="error">{errors.startTime}</span>}
                  </div>

                  {formData.startTime && !showCustomEndTime && (
                    <div style={{background: "#e8f5e9", padding: "10px", borderRadius: "8px", border: "1px solid #c8e6c9", display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "10px"}}>
                      <span style={{fontSize: "14px", color: "#2e7d32", fontWeight: "500"}}>
                        Duration: 1 Hour (Ends at {(() => {
                          const [h, m] = formData.startTime.split(":").map(Number);
                          return `${((h + 1) % 24).toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}`;
                        })()})
                      </span>
                      <button 
                        type="button" 
                        onClick={() => setShowCustomEndTime(true)}
                        style={{background: "#1e3c72", color: "white", border: "none", padding: "5px 10px", borderRadius: "4px", fontSize: "12px", cursor: "pointer"}}
                      >
                        Change End Time
                      </button>
                    </div>
                  )}

                  {showCustomEndTime && (
                    <div style={{marginBottom: "10px"}}>
                      <div style={{display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "5px"}}>
                        <label style={{fontSize: "14px", fontWeight: "600"}}>End Time</label>
                        <button 
                          type="button" 
                          onClick={() => {
                            setShowCustomEndTime(false);
                            setFormData(prev => ({...prev, endTime: ""}));
                          }}
                          style={{background: "none", border: "none", color: "#d32f2f", fontSize: "12px", cursor: "pointer", textDecoration: "underline"}}
                        >
                          Reset to 1 Hour
                        </button>
                      </div>
                      <input
                        type="time"
                        name="endTime"
                        value={formData.endTime}
                        onChange={handleChange}
                        style={{width: "100%"}}
                      />
                      {errors.endTime && <span className="error">{errors.endTime}</span>}
                    </div>
                  )}
                </div>
              </>
            )}

            {selectedAreaDetails && (
              <div className="slot-grid-container" style={{marginTop: "20px"}}>
                <label style={{display: "block", marginBottom: "10px", fontSize: "14px", fontWeight: "600"}}>
                  Select Parking Slot {availability.loading && <span style={{fontSize: "12px", color: "#666", marginLeft: "10px"}}>(Updating availability...)</span>}
                </label>
                <div style={{display: "flex", gap: "15px", marginBottom: "15px", fontSize: "12px", color: "white", fontWeight: "600"}}>
                  <div style={{display: "flex", alignItems: "center", gap: "5px"}}>
                    <div style={{width: "12px", height: "12px", background: "rgba(16, 185, 129, 0.3)", border: "1px solid #10b981", borderRadius: "3px"}}></div>
                    <span>Available</span>
                  </div>
                  <div style={{display: "flex", alignItems: "center", gap: "5px"}}>
                    <div style={{width: "12px", height: "12px", background: "rgba(239, 68, 68, 0.3)", border: "1px solid #ef4444", borderRadius: "3px"}}></div>
                    <span>Booked</span>
                  </div>
                  <div style={{display: "flex", alignItems: "center", gap: "5px"}}>
                    <div style={{width: "12px", height: "12px", background: "rgba(245, 158, 11, 0.3)", border: "1px solid #f59e0b", borderRadius: "3px"}}></div>
                    <span>Locked</span>
                  </div>
                </div>
                <div className="slot-grid" style={{
                  display: "grid", 
                  gridTemplateColumns: "repeat(5, 1fr)", 
                  gap: "10px",
                  background: "rgba(255, 255, 255, 0.05)",
                  padding: "15px",
                  borderRadius: "20px",
                  border: "1px solid rgba(255, 255, 255, 0.1)",
                  backdropFilter: "blur(10px)"
                }}>
                  {Array.from({ length: availability.totalSlots || selectedAreaDetails.totalSlots }, (_, i) => i + 1).map(num => {
                    const isBooked = availability.bookedSlots.includes(num);
                    const isPending = availability.pendingSlots.includes(num);
                    const isSelected = formData.slotNumber === num;
                    return (
                      <div 
                        key={num}
                        onClick={() => {
                          if (isBooked || isPending) {
                            alert(isPending ? "This slot is temporarily locked for payment. Please wait 2 minutes." : "This slot is already booked for the selected time.");
                            return;
                          }
                          setFormData({...formData, slotNumber: num});
                        }}
                        style={{
                          height: "60px",
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "center",
                          justifyContent: "center",
                          borderRadius: "14px",
                          cursor: (isBooked || isPending) ? "not-allowed" : "pointer",
                          background: isSelected 
                            ? "linear-gradient(135deg, #3b82f6, #2563eb)" 
                            : (isBooked ? "rgba(239, 68, 68, 0.2)" : (isPending ? "rgba(245, 158, 11, 0.2)" : "rgba(16, 185, 129, 0.2)")),
                          color: isSelected ? "#ffffff" : (isBooked ? "#ef4444" : (isPending ? "#f59e0b" : "#10b981")),
                          border: isSelected 
                            ? "2px solid #ffffff" 
                            : (isBooked ? "1px solid rgba(239, 68, 68, 0.4)" : (isPending ? "1px solid rgba(245, 158, 11, 0.4)" : "1px solid rgba(16, 185, 129, 0.4)")),
                          fontWeight: "900",
                          fontSize: "16px",
                          transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                          boxShadow: isSelected ? "0 0 20px rgba(59, 130, 246, 0.5)" : "none",
                          transform: isSelected ? "scale(1.05)" : "scale(1)",
                        }}
                        title={isBooked ? "Already Booked" : (isPending ? "Locked for Payment" : "Available")}
                      >
                        <span style={{fontSize: "9px", opacity: 0.8, marginBottom: "2px", letterSpacing: "1px"}}>SLOT</span>
                        {num}
                      </div>
                    );
                  })}
                </div>
                {errors.slotNumber && <span className="error">{errors.slotNumber}</span>}
              </div>
            )}

            <div className="form-group-fixed" style={{marginBottom: "15px"}}>
              <label style={{display: "block", marginBottom: "5px", fontSize: "14px", fontWeight: "600"}}>Total Price</label>
              <input
                type="text"
                name="price"
                value={formData.price ? `₹${formData.price}` : ""}
                readOnly
                placeholder="Total calculated price"
              />
              {selectedAreaDetails && (
                <small style={{color: "#666", fontSize: "12px"}}>
                  (Hourly Rate: ₹{selectedAreaDetails.price}/hr)
                </small>
              )}
            </div>

            <div className="form-group-fixed" style={{marginBottom: "15px"}}>
              <label style={{display: "block", marginBottom: "5px", fontSize: "14px", fontWeight: "600"}}>Payment Method</label>
              <select
                name="paymentMethod"
                value={formData.paymentMethod}
                onChange={handleChange}
              >
                <option value="">Choose Method</option>
                <option value="QR">QR Code</option>
                <option value="UPI_ID">UPI ID Payment</option>
              </select>
            </div>
            {errors.paymentMethod && <span className="error">{errors.paymentMethod}</span>}

            <button type="submit" className="booking-btn" disabled={isProcessing}>
              {isProcessing ? "Processing..." : "Continue to Confirm"}
            </button>
          </form>
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" style={{position: "fixed", top: 0, left: 0, width: "100%", height: "100%", background: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 1100}}>
          <div className="modal-content-custom" style={{background: "white", padding: "30px", borderRadius: "12px", width: "400px", maxWidth: "90%"}}>
            <div className="modal-header" style={{display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px", borderBottom: "1px solid #eee", paddingBottom: "10px"}}>
              <h3>Complete Booking</h3>
              <button
                className="close-btn"
                onClick={handleCloseModal}
                style={{background: "none", border: "none", fontSize: "24px", cursor: "pointer"}}
              >
                ×
              </button>
            </div>

            <div className="modal-body">
              {paymentSuccess ? (
                <div style={{textAlign: "center", padding: "20px"}}>
                  <div style={{color: "green", fontSize: "50px", marginBottom: "15px"}}>✓</div>
                  <h2 style={{color: "green", marginBottom: "10px"}}>Payment Successful</h2>
                  <p style={{fontSize: "14px", color: "#666", marginTop: "15px"}}>Redirecting to profile page...</p>
                </div>
              ) : (formData.paymentMethod === "QR" || formData.paymentMethod === "UPI_ID") ? (
                <div style={{textAlign: "center"}}>
                  <div style={{background: "#f8f9fa", padding: "15px", borderRadius: "10px", marginBottom: "20px"}}>
                    <h4 style={{margin: "0 0 10px 0", color: "#1e3c72"}}>
                      {formData.paymentMethod === "QR" ? "Scan to Pay" : "UPI ID Payment"}
                    </h4>
                    <p style={{fontSize: "20px", fontWeight: "bold", color: "#2e7d32", margin: "5px 0"}}>Amount: ₹{formData.price}</p>
                    <p style={{fontSize: "12px", color: "#666", marginBottom: "15px"}}>Slot: {formData.slotNumber} | Area: {formData.area}</p>
                    
                    {formData.paymentMethod === "QR" ? (
                      <div style={{background: "white", padding: "15px", borderRadius: "8px", display: "inline-block", boxShadow: "0 4px 12px rgba(0,0,0,0.1)"}}>
                         <QRCodeCanvas 
                           value={upiLink}
                           size={180}
                           level="H"
                         />
                       </div>
                    ) : !isUpiValidated ? (
                      <div style={{marginTop: "10px", textAlign: "left"}}>
                        <label style={{display: "block", marginBottom: "8px", fontWeight: "bold", fontSize: "14px"}}>Enter UPI ID</label>
                        <input 
                          type="text" 
                          value={upiId} 
                          onChange={(e) => setUpiId(e.target.value)} 
                          placeholder="example@upi" 
                          style={{width: "100%", padding: "12px", borderRadius: "6px", border: "1px solid #ccc", marginBottom: "10px", boxSizing: "border-box", fontSize: "16px"}}
                        />
                        {upiError && <span style={{color: "red", fontSize: "12px"}}>{upiError}</span>}
                        <button 
                          onClick={handleUpiValidation} 
                          disabled={isProcessing} 
                          style={{width: "100%", padding: "12px", borderRadius: "6px", border: "none", background: "#1e3c72", color: "white", fontWeight: "bold", cursor: "pointer"}}
                        >
                          {isProcessing ? "Processing..." : "Request Payment"}
                        </button>
                      </div>
                    ) : (
                      <div style={{marginTop: "10px", padding: "10px", background: "#e8f5e9", borderRadius: "8px"}}>
                        <p style={{color: "#2e7d32", fontWeight: "bold", margin: 0}}>Request sent to {upiId}</p>
                        <p style={{fontSize: "12px", color: "#666", marginTop: "5px"}}>Check your UPI app to complete payment.</p>
                      </div>
                    )}
                    
                    {showQR && (
                       <div style={{marginTop: "20px", fontSize: "20px", fontWeight: "bold", color: "#d9534f"}}>
                         Auto-confirming in {countdown}s...
                       </div>
                    )}
                    
                    {(formData.paymentMethod === "QR" || isUpiValidated) && (
                      <p style={{fontSize: "12px", color: "#1e3c72", marginTop: "10px", fontWeight: "600"}}>milanparmar568-1@oksbi</p>
                    )}
                  </div>

                  {(formData.paymentMethod === "QR" || isUpiValidated) && (
                    !paymentSuccess && (
                      <div style={{textAlign: "center"}}>
                        <p style={{fontSize: "13px", color: "#666", marginBottom: "15px"}}>
                          {formData.paymentMethod === "QR" ? "Scan with any UPI app to pay." : "Complete payment in your UPI app."}
                        </p>
                        <button 
                          onClick={() => {
                            setIsProcessing(true);
                            setTimeout(() => {
                              setIsProcessing(false);
                              setPaymentSuccess(true);
                              setShowQR(false);
                              setTimeout(() => {
                                handleAutoConfirm();
                              }, 1500);
                            }, 1500);
                          }}
                          className="booking-btn"
                          style={{width: "100%", background: "#2e7d32"}}
                          disabled={isProcessing}
                        >
                          {isProcessing ? "Verifying..." : "I have paid"}
                        </button>
                      </div>
                    )
                  )}
                </div>
              ) : (
                <div style={{textAlign: "center"}}>
                  <p style={{margin: "10px 0"}}><strong>Area:</strong> {formData.area}, {formData.city}</p>
                  <p style={{margin: "10px 0"}}><strong>Vehicle:</strong> {formData.vehicleNumber} ({formData.vehicleType})</p>
                  <p style={{margin: "10px 0"}}><strong>Price:</strong> ₹{formData.price}</p>
                  <p style={{margin: "10px 0"}}><strong>Payment:</strong> {formData.paymentMethod}</p>
                  <div style={{display: "flex", gap: "10px", marginTop: "25px"}}>
                    <button onClick={handleCloseModal} style={{flex: 1, padding: "12px", borderRadius: "6px", border: "1px solid #ddd", background: "white", cursor: "pointer", fontWeight: "bold"}}>Cancel</button>
                    <button onClick={confirmFinalBooking} disabled={isProcessing} style={{flex: 1, padding: "12px", borderRadius: "6px", border: "none", background: "#1e3c72", color: "white", fontWeight: "bold", cursor: "pointer"}}>{isProcessing ? "Processing..." : "Confirm"}</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Booking;

