import React, { useEffect, useState } from "react";
import { dashboardService } from "../../services/api";
import { useOutletContext } from "react-router-dom";
import {
  MdTrendingUp,
  MdTrendingDown,
  MdMoreVert,
  MdList,
  MdCalendarToday,
  MdAccountBalanceWallet,
  MdEventAvailable,
  MdDirectionsCar,
  MdLocalParking
} from "react-icons/md";
import "./Dashboard.css";

const Dashboard = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("All");
  const { searchTerm } = useOutletContext();

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await dashboardService.getStats();
        setData(res.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching stats:", error);
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  if (loading) return <div className="loading">Loading Dashboard...</div>;
  if (!data) return <div className="error">Failed to load dashboard data.</div>;

  const summary = data.summary || {};
  const recentBookings = data.recentBookings || [];

  // ✅ FILTER LOGIC (SEARCH + TAB)
  const filteredBookings = recentBookings.filter((booking) => {
    const searchLower = searchTerm?.toLowerCase() || "";

    const matchesSearch =
      booking.userId?.name?.toLowerCase().includes(searchLower) ||
      booking.vehicleNumber?.toLowerCase().includes(searchLower) ||
      booking.area?.toLowerCase().includes(searchLower) ||
      booking._id.slice(-6).toUpperCase().includes(searchLower.toUpperCase());

    if (activeTab === "All") return matchesSearch;

    if (activeTab === "Active") {
      return matchesSearch &&
        ["allocated", "extended", "overtime"].includes(booking.status?.toLowerCase()) &&
        !(booking.status?.toLowerCase() === "overtime" && booking.paymentStatus === "Paid");
    }

    if (activeTab === "Completed") {
      return matchesSearch && (
        booking.status?.toLowerCase() === "completed" ||
        (booking.status?.toLowerCase() === "overtime" && booking.paymentStatus === "Paid")
      );
    }
  });

  // ✅ TABS WITH COUNTS
  const tabs = [
    { name: "All", count: recentBookings.length },
    {
      name: "Active",
      count: recentBookings.filter(b =>
        ["allocated", "extended", "overtime"].includes(b.status?.toLowerCase()) &&
        !(b.status?.toLowerCase() === "overtime" && b.paymentStatus === "Paid")
      ).length
    },
    {
      name: "Completed",
      count: recentBookings.filter(b =>
        b.status?.toLowerCase() === "completed" ||
        (b.status?.toLowerCase() === "overtime" && b.paymentStatus === "Paid")
      ).length
    },
  ];

  return (
    <div className="dashboard-container">

      {/* HEADER */}
      <div className="dashboard-header-main">
        <h1 className="page-title">Dashboard</h1>
        <div className="header-actions">
          <button className="icon-action-btn"><MdList /></button>
          <button className="icon-action-btn"><MdCalendarToday /></button>
        </div>
      </div>

      {/* STATS */}
      <div className="stats-grid-modern">
        <StatCardModern
          title="Total Revenue"
          value={`₹${(summary.totalRevenue || 0).toLocaleString()}`}
          isPositive={true}
          icon={<MdAccountBalanceWallet />}
          type="revenue"
        />
        <StatCardModern
          title="Total Bookings"
          value={summary.totalBookings || 0}
          isPositive={true}
          icon={<MdEventAvailable />}
          type="bookings"
        />
        <StatCardModern
          title="Total Slots"
          value={summary.totalParkingSlots || 0}
          isPositive={true}
          icon={<MdLocalParking />}
          type="total-slots"
        />
        <StatCardModern
          title="Available Slots"
          value={summary.availableSlots || 0}
          isPositive={true}
          icon={<MdDirectionsCar />}
          type="available-slots"
        />
      </div>

      {/* TABS */}
      <div className="tabs-container">
        {tabs.map((tab) => (
          <button
            key={tab.name}
            className={`tab-btn ${activeTab === tab.name ? "active" : ""}`}
            onClick={() => setActiveTab(tab.name)}
          >
            {tab.name}
            <span className="tab-count">{tab.count}</span>
          </button>
        ))}
      </div>

      {/* TABLE */}
      <div className="modern-table-container">
        <div className="table-header">
          <h2>Recent Bookings</h2>
        </div>

        <table className="staywise-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Customer</th>
              <th>Area / Location</th>
              <th>Vehicle No.</th>
              <th>Date & Time</th>
              <th>Amount</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>

          <tbody>
            {filteredBookings.length > 0 ? (
              filteredBookings.map((booking) => (
                <tr key={booking._id}>

                  {/* ID */}
                  <td className="row-id">
                    #{booking._id.slice(-4).toUpperCase()}
                  </td>

                  {/* CUSTOMER */}
                  <td>
                    <div className="customer-cell">
                      <img
                        src={`https://ui-avatars.com/api/?name=${booking.userId?.name || "U"}&background=random`}
                        alt="avatar"
                        className="customer-avatar"
                      />
                      <div className="customer-info">
                        <span className="customer-name">
                          {booking.userId?.name || "Deleted User"}
                        </span>
                        <span className="customer-subtext">
                          {booking.userId?.email || booking.email || "No email"}
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* AREA */}
                  <td>{booking.area}</td>

                  {/* VEHICLE */}
                  <td>
                    <span className="vehicle-badge">
                      {booking.vehicleNumber}
                    </span>
                  </td>

                  {/* DATE */}
                  <td>
                    <div className="date-cell">
                      <span className="main-date">
                        {new Date(booking.startTime).toLocaleDateString()}
                      </span>
                      <span className="sub-time">
                        {new Date(booking.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} -
                        {new Date(booking.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </td>

                  {/* AMOUNT */}
                  <td>
                    <div className="amount-cell">
                      <span className="main-amount">₹{(booking.amount || 0) + (booking.extraCharge || 0)}</span>
                      {booking.extraCharge > 0 && (
                        <span className="extra-charge-sub" style={{ fontSize: '10px', color: '#e53e3e', display: 'block' }}>
                          (+₹{booking.extraCharge} {(booking.status === 'Completed' || (booking.status === 'Overtime' && booking.paymentStatus === 'Paid')) ? 'Extra' : 'Overtime'})
                        </span>
                      )}
                    </div>
                  </td>

                  {/* STATUS */}
                  <td>
                    <span className={`status-pill ${booking.status?.toLowerCase() === 'overtime' && booking.paymentStatus === 'Paid' ? 'completed' : booking.status?.toLowerCase()}`}>
                      {booking.status?.toLowerCase() === 'overtime' && booking.paymentStatus === 'Paid' ? 'Completed' : booking.status}
                    </span>
                  </td>

                  {/* ACTION */}
                  <td>
                    <button className="more-btn">
                      <MdMoreVert />
                    </button>
                  </td>

                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="8" className="no-data">
                  No bookings found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ✅ STAT CARD COMPONENT
const StatCardModern = ({ title, value, isPositive, icon, type }) => {
  return (
    <div className="stat-card-modern">
      <div className="stat-header">
        <span className="stat-title">{title}</span>
        <div className={`stat-icon-wrapper ${type}`}>
          {icon}
        </div>
      </div>
      <div className="stat-value-container">
        <h3 className="stat-value-main">{value}</h3>
        <div className={`stat-trend-modern ${isPositive ? "positive" : "negative"}`}>
          {isPositive ? <MdTrendingUp /> : <MdTrendingDown />}
          <span>{isPositive ? "+12.5%" : "-2.4%"}</span>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;